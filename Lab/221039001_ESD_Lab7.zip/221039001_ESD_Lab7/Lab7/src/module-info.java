/**
 * 
 */
/**
 * @author HP
 *
 */
module Lab7 {
}