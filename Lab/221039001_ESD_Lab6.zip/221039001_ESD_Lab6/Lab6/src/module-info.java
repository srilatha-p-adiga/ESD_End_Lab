/**
 * 
 */
/**
 * @author HP
 *
 */
module Lab6 {
}