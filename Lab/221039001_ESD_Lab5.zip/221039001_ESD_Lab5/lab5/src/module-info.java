/**
 * 
 */
/**
 * @author HP
 *
 */
module lab5 {
}