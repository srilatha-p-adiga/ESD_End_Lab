/**
 * 
 */
/**
 * @author HP
 *
 */
module lambda_assignment {
}