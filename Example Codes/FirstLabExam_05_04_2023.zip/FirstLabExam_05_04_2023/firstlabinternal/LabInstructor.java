package firstlabinternal;

public class LabInstructor {

}
