package firstlabinternal;

public class TestComputerLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s[] = {new Student("ravi", 111), new Student("suresh", 222), new Student("satish", 333) };
	
		ApplicationSoftware app[] = { new ApplicationSoftware("oracle", "db"),
										new ApplicationSoftware("sublime", "editor"),
										new ApplicationSoftware("studio", "developer")};
		SystemSoftware sys[] = {new SystemSoftware("windows", "MS", 1),
								new SystemSoftware("linux", "MS", 2),
								new SystemSoftware("mac", "apple", 3)};
		
		PersonalComputer pc[] = {new PersonalComputer("Desktop-1",app[0], sys[0]),
									new PersonalComputer("Desktop-2",app[1], sys[1]),
									new PersonalComputer("Desktop-3",app[2], sys[2])};
		
		
		
	}

}
