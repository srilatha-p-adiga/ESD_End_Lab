package firstlabinternal;

public class ApplicationSoftware extends Software {
	
	private String type;

	public ApplicationSoftware(String name, String type) {
		super(name);
		// TODO Auto-generated constructor stub
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	

}
