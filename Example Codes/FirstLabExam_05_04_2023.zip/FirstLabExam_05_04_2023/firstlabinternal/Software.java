package firstlabinternal;

public class Software {
	
	private String name;
	
	public Software(String name) {
		// TODO Auto-generated constructor stub
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public boolean uninstall() {
		this.name = "";
		return true;
	}
	
	public boolean install(String name) {
		this.name = name;
		return true;
	}
	
	public boolean upgarde(String name) {
		this.name = name;
		return true;
	}

}
