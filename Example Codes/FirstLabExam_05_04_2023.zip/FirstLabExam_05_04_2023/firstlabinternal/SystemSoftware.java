package firstlabinternal;

public class SystemSoftware extends Software {

	private String target_architecture;
	private float version;
	
	public SystemSoftware(String name, String target_architecture, float version) {
		super(name);
		// TODO Auto-generated constructor stub
		this.target_architecture = target_architecture;
		this.version = version;
	}
	
	
	
}
