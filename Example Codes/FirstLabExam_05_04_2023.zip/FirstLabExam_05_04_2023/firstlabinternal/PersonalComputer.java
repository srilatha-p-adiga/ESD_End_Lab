package firstlabinternal;

public class PersonalComputer {
	
	private String hostname;
	private Student student;
	private LabInCharge lab_incharge;
	private ApplicationSoftware app_soft;
	private SystemSoftware sys_soft;
	
	public PersonalComputer() {
		// TODO Auto-generated constructor stub
	}
	
	public PersonalComputer(String hostname, ApplicationSoftware app_soft, SystemSoftware sys_soft) {
		// TODO Auto-generated constructor stub
		this.hostname = hostname;
		this.app_soft = app_soft;
		this.sys_soft = sys_soft;
	}
	
	public void allotStudent(Student student) {
		this.student = student;
	}
	
	public void allotLabIncharge(LabInCharge lab_incharge) {
		this.lab_incharge = lab_incharge;
	}
	
	public Student getStudent() {
		return this.student;
	}
	
	public LabInCharge getLabInCharge() {
		return this.lab_incharge;
	}
	
	public ApplicationSoftware getAppSoft() {
		return this.app_soft;
	}
	
	public SystemSoftware getSysSoft() {
		return this.sys_soft;
	}
	
	public String getHostname() {
		return this.hostname;
	}

}
