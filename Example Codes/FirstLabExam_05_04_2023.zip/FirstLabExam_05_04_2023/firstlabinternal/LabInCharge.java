package firstlabinternal;

public class LabInCharge {

}
