package firstlabinternal;

public class Student {
	
	private String name;
	private int regno;
	
	public Student(String name, int regno) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.regno = regno;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getRegno() {
		return this.regno;
	}

}
