
public class TestCompare{
	public static void main(String[] args) {
		
		CompareGen<Integer> obj1 = new CompareGen<Integer>(new Integer(20));

		CompareGen<Double> obj2 = new CompareGen<Double>(new Double(21.0));

		boolean flag = obj1.compare(obj2);

		if(flag == true){
			System.out.println("Both values are true");
		}
		else{
			System.out.println("value differ");
		}

	}
}