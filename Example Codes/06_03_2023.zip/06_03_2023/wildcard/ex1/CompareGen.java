class CompareGen<T extends Number>{

	T numObject;
	
	CompareGen(T obj){
		this.numObject = obj;
	}


	boolean compare(CompareGen<?> obj2){
		
		if(this.numObject.doubleValue() == obj2.numObject.doubleValue())
			return true;
		else
			return false;
	}
}