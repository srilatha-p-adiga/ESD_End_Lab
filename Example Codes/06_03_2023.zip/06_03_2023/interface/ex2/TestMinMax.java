
public class TestMinMax{

	public static void main(String[] args) {
		
		Integer[] i = {2, 4, 56, 23, 55, 12};
		MyClass<Integer> obj = new MyClass<Integer>(i);

		Double[] d = {2.0, 4.5, 3.8, 6.8,1.9};
		MyClass<Double> obj1 = new MyClass<Double>(d);

		assert(obj.min() == 2);
		assert(obj.max() == 56);

		assert(obj1.min() == 1.9);
		assert(obj1.max() == 6.8);		

	}
}