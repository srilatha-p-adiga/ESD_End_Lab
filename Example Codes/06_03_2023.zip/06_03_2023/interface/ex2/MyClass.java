class MyClass<T extends Comparable<T>> implements MinMax<T>
{

	T vals[];

	MyClass(T arr[]){
		vals = arr;
	}

	public T min(){
		T value = vals[0];
		for(int i=1;i<vals.length;i++)
			if(vals[i].compareTo(value)<0)
				value = vals[i];
		return value;
	}

	public T max(){
		T value = vals[0];
		for(int i=1;i<vals.length;i++)
			if(vals[i].compareTo(value)>0)
				value = vals[i];
		return value;
	}
}