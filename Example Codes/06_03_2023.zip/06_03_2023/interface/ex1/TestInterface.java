interface Shape<T>
{
	void fillObj(T obj);
}


class Gen<T> implements Shape<T>{

	public void fillObj(T obj){
		System.out.println(obj);
	}
}

public class TestInterface{
	public static void main(String[] args) {
		Gen<Integer> obj = new Gen<Integer>();
		obj.fillObj(new Integer(30));

		Gen<String> obj1 = new Gen<String>();
		obj1.fillObj("hello....");
	}
}