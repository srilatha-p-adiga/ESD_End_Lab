
public class Stats<T>{

	T[] nums;
	Stats(T[] n){
		nums = n;
	}

	double average(){

		
	}

	boolean same_Avg(Stats<T> obj){
		if(this.average() == obj.average())
			return true;
		return false;
	}
}