
public class TestSum{
	public static void main(String[] args) {
		
		Integer a[] = {3,6,7,8};
		Sum<Integer> obj = new Sum<Integer>(a);
		System.out.println("Average is: " + obj.average());

		Double d[] = {33.3,66.6,77.7,88.8};
		Sum<Double> obj1 = new Sum<Double>(d);
		System.out.println("Average is: " + obj1.average());
	}
}