class Sum<T>{

	T[] nums;
	Sum(T[] n){
		nums = n;
	}

	double average(){

		
	}
}